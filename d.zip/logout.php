<?php
    require_once 'db.php';
    session_start();
    if(isset($_SESSION['user'])){
        unset($_SESSION['user']);
        $_SESSION["succ"] = "Wylogowano!";
        header("Location: index.php");
        exit();        
    }else{
            header("Location: index.php");
            exit();           
    }
?>